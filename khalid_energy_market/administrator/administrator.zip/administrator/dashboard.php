<?php session_start();
    include 'pdo_class_data.php';
    include 'connection.php';
    $pdo_auth = authenticate_admin();
    $pdo = new PDO($dsn, $user, $pass, $opt);
    include 'function.php';

?><!DOCTYPE html>
<html>
<head>
    <?php include 'head.php'; ?>
    <title><?php include 'title.php'; ?></title>   
    
  </head>
<body class="sidebar-mini fixed  pace-done sidebar-collapse">
    <div class="wrapper">
      <!-- Navbar-->
      <?php include 'navbar.php'; ?>

      <div class="content-wrapper " style="">
         <div class="page-title" style="padding: 32px;background-color: #0e1354;box-shadow: 0px 2px 10px rgba(0,0,0,.2);">
          <div class="row" style="width: 100%;margin-left:0px;">
           <div class="col-sm-3 lft">
            <div style="padding: 20px;" class="mobss"></div>
              <div class="lft_pad">
                <div style="padding: 10px;"></div>
                <h1 style="font-family: 'Century Gothic';color: #999;font-size: 25px;font-weight: normal;"><div style="font-weight: bold;color: #55b3dd"><?php echo wallet_names(); ?> Admin </div><span style="font-size: 14px;">Sale Dashboard</span></h1>
                
              </div>
           </div>
           <div class="col-sm-9">
             <?php include 'price_panel.php';  ?>
           </div>
          
          </div>
        </div>

        
        <?php see_status2($_REQUEST); ?>
        <?php include 'dashboard_stats.php'; ?>          
        <!-- <?php include 'dashboard_chart.php'; ?> -->
        
        <div class="row">
         
          <div class="col-md-12">
            <div class="card">
              <h3 style="font-family: 'Century Gothic';font-weight: normal;font-size: 20px;color:#666;">Whitelisted Users</h3>
              <div class="table-responsive">
                <table class="table table-hover table-striped  dataTable no-footer" id="example23">
                  <thead>
                    <tr style="color:#888;">
                      <th>#</th>
                      <th> Name</th>
                      <th>Email</th>
                      <th>Tx Address</th>
                      <th>File </th>
                      <th>Gender </th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                     
                      try {
                          $stmt = $pdo->prepare('SELECT * FROM `users`  ORDER BY date DESC');
                      } catch(PDOException $ex) {
                          echo "An Error occured!"; 
                          print_r($ex->getMessage());
                      }
                      $stmt->execute();
                      $user = $stmt->fetchAll();
                      $i=1;
                      foreach ($user as $key => $value) {
                        echo ' <tr>
                                <td>'.$i.'</td>
                                <td>'.$value['name'].'</td>
                                <td>'.$value['email'].'</td>
                                 <td><label class="label label-success">'.$value['tx_address'].'</label></td>
                               <td><img src="../profile/'.$value['file'].'" style="width:30px;"></td>
                                <td>'.$value['gender'].'</td>
                                <td>'.$value['verified'].'</td>
                                <td>
                                  <button class="btn btn-info btn-sm" title="Delete"><i class="icon-remove-sign"></i></button>
                                </td>
                              </tr>';
                              $i++;
                      }
                     ?>
                    
                  </tbody>
                </table>
              </div>
              
            </div>
          </div>
        </div>
      
     <?php include 'footer.php'; ?>
      
      
      </div>
    </div>
    <div id="gora" ></div>
    


<?php include 'update_modal.php'; ?>
    

    <!-- Javascripts-->
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/pace.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/plugins/chart.js"></script>
    <!--<script type="text/javascript">
      var data = {
        labels: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
        datasets: [
          
          {
            label: "My Second dataset",
            fillColor: "rgba(151,187,205,0.2)",
            strokeColor: "rgba(151,187,205,1)",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(151,187,205,1)",
            data: [<?php echo $non_zero[0] ?>, <?php echo $non_zero[1] ?>,<?php echo $non_zero[2] ?>,<?php echo $non_zero[3] ?>,<?php echo $non_zero[4] ?>, <?php echo $non_zero[5] ?>, <?php echo $non_zero[6] ?>, <?php echo $non_zero[7] ?>, <?php echo $non_zero[8] ?>, <?php echo $non_zero[10] ?>]
          }
        ]
      };

      var mata = {
        labels: [">0 ETH", ">1 ETH", ">3ETH", ">4 ETH", ">5 ETH"],
        datasets: [
          
          {
            label: "My Second dataset",
            fillColor: "rgba(151,187,205,0.2)",
            strokeColor: "rgba(151,187,205,1)",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(151,187,205,1)",
            data: [<?php echo count($array1) ?>, <?php echo count($array2) ?>, <?php echo count($array3) ?>, <?php echo count($array4) ?>, <?php echo count($array5) ?>]
          }
        ]
      };

      var pdata = [
        {
          value: <?php echo $total_supply; ?>,
          color:"#666",
          highlight: "#999",
          label: "Total Tokens"
        },
        {
          value: <?php echo $tokens_sold; ?>,
          color: "#333",
          highlight: "#555",
          label: "Sold Tokens"
        },
        {
          value: <?php echo $tokens_left; ?>,
          color: "#666",
          highlight: "#999",
          label: "Available Tokens"
        }
      ]
      
      var ctxl = $("#lineChartDemo").get(0).getContext("2d");      
      var lineChart = new Chart(ctxl).Line(data);
      
      var ctxb = $("#barChartDemo").get(0).getContext("2d");
      var barChart = new Chart(ctxb).Bar(mata);
      
    
      var ctxp = $("#pieChartDemo").get(0).getContext("2d");
      var barChart = new Chart(ctxp).Pie(pdata);
      
    </script>-->
    
    <script type="text/javascript">
      var data = {
        labels: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
        datasets: [
          
          {
            label: "My Second dataset",
            fillColor: "rgba(151,187,205,0.2)",
            strokeColor: "#091496",
            pointColor: "#2196f3",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(151,187,205,1)",
            data: [0.0035, 0.0035,0.005,0.07,0.322, 0.744, 0.03732525, 4.945, 0.016, 4.945]
          }
        ]
      };

      var mata = {
        labels: [">0 ETH", ">1 ETH", ">3ETH", ">4 ETH", ">5 ETH"],
        datasets: [
          
          {
            label: "My Second dataset",
            fillColor: "rgba(200,200,205,0.2)",
            strokeColor: "#091496",
            pointColor: "rgba(151,187,205,1)",
            pointStrokeColor: "#fff",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(151,187,205,1)",
            data: [21, 10, 3, 7, 54]
          }
        ]
      };

      var pdata = [
        {
          value: 100000000,
          color:"#091496",
          highlight: "#213956",
          label: "Total Tokens"
        },
        {
          value: 24999900,
          color: "#0a7d79",
          highlight: "#213956",
          label: "Sold Tokens"
        },
        {
          value: 100,
          color: "#ddd",
          highlight: "#0e538e",
          label: "Available Tokens"
        }
      ]
      
      var ctxl = $("#lineChartDemo").get(0).getContext("2d");      
      var lineChart = new Chart(ctxl).Line(data);
      
      var ctxb = $("#barChartDemo").get(0).getContext("2d");
      var barChart = new Chart(ctxb).Bar(mata);
      
    
      var ctxp = $("#pieChartDemo").get(0).getContext("2d");
      var barChart = new Chart(ctxp).Pie(pdata);
      
    </script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.4.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.4.2/js/buttons.print.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
          $('#example').DataTable( {
              dom: 'Bfrtip',
              buttons: [
                  'copy', 'csv', 'excel', 'pdf', 'print'
              ]
          } );


          $('#example23').DataTable( {
              dom: 'Bfrtip',
              buttons: [
                  'copy', 'csv', 'excel', 'pdf', 'print'
              ]
          } );


          $("#mota").click(function(){
            //alert("hello");
            $("#gora").load("change_notif_status.php");
          });

      } );
    </script>    
  </body>


</html>