<div style="padding-left:70px;">
       <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12" style="padding: 0px;">
            <div style="font-size: 12px;text-align:left;color:#555" class="resp">Copyright ©<?php echo date("Y"); ?>, All Rights Reserved.  Powered By <a href="" style="color:#53c3f5"><?php echo wallet_names(); ?> </a></div>
          </div>
        </div>
    </div>

     
